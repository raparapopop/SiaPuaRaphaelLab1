package com.sample;

public class Tire {
	
	private int pressure;
	private String color;
	private int diameter;
	private String threadtype;
	
	
	
	public Tire(int pressure, String color, int diameter, String threadtype) {
		super();
		this.pressure = pressure;
		this.color = color;
		this.diameter = diameter;
		this.threadtype = threadtype;
	}
	public int getPressure() {
		return pressure;
	}
	public void setPressure(int pressure) {
		this.pressure = pressure;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getDiameter() {
		return diameter;
	}
	public void setDiameter(int diameter) {
		this.diameter = diameter;
	}
	public String getThreadtype() {
		return threadtype;
	}
	public void setThreadtype(String threadtype) {
		this.threadtype = threadtype;
	}
	
	
	public void inlate(int bypounds) {
		this.pressure = bypounds;
		
	}
	

}
