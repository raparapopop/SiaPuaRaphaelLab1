package com.sample;

public class Test {

	public static void main(String[] args) {
		
	
		
		
		Car c1 = new Car(2000, "Black", "123 ABC", "Toyota");
		System.out.println("Properties of Car C1:");
		System.out.println("Year: " + c1.getYear());
		System.out.println("Color: " + c1.getColor());
		System.out.println("License Number: " + c1.getLicensenumber());
		System.out.println("Model: " + c1.getModel());
		
		
	}
	
	

}